﻿using System;

namespace LinqConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            var d = new LinqSamples();
            //d.Przyklad1();
        }
    }
}
